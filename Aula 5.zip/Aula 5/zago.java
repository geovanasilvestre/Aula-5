// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class zago extends Actor
{

    /**
     * Act - do whatever the zago wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(6);
        
        if (Greenfoot.isKeyDown("left")) {
            turn(-6);
        }
        if (Greenfoot.isKeyDown("right")) {
            turn(6);
        }
        if (Greenfoot.isKeyDown("up")) {
            turn(8);
        }
        if (Greenfoot.isKeyDown("down")) {
            turn(-8);
        }
    }
}
