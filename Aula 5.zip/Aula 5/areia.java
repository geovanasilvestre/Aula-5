// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class areia extends World
{

    /**
     * Constructor for objects of class areia.
     */
    public areia()
    {
        super(600, 400, 1);
    }
}
